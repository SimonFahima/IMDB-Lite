package com.company.simon.imdblite;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.squareup.picasso.Picasso;
import java.util.List;

import androidx.fragment.app.FragmentActivity;


public class MovieAdapter extends ArrayAdapter<Movie> {

    private Activity activity;
    private List<Movie> movies;
    private FragmentActivity fragmentActivity;

    public MovieAdapter(Activity activity, List<Movie> movies, FragmentActivity fragmentActivity) {
        super(activity, R.layout.movie_card, movies);
        this.activity = activity;
        this.movies = movies;
        this.fragmentActivity = fragmentActivity;
    }

    static class ViewContainer{
        ImageView imgMoviePoster;
        TextView txtMovieName;
        LinearLayout linearLayoutMovieCard;
    }



    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int position, final View convertView, ViewGroup parent) {
        final ViewContainer viewContainer;
        View view = convertView;
        if(view == null){
            viewContainer = new ViewContainer();
            view = activity.getLayoutInflater().inflate(R.layout.movie_card,parent,false);
            viewContainer.imgMoviePoster = view.findViewById(R.id.imgMoviePoster);
            viewContainer.txtMovieName = view.findViewById(R.id.txtMovieName);
            viewContainer.linearLayoutMovieCard = view.findViewById(R.id.linearLayoutMovieCard);
            view.setTag(viewContainer);
            viewContainer.linearLayoutMovieCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = (int) view.getTag();
                    Movie movie = movies.get(position);
                    Log.d(Variables.ADMIN, "clicked on " + movie.getTitle());
                    Toast.makeText(activity, "" + movie.getTitle(), Toast.LENGTH_SHORT).show();
                    MovieInfoFragment movieInfoFragment = new MovieInfoFragment();
                    movieInfoFragment.show(fragmentActivity.getSupportFragmentManager(), "");
                    //handle onclick event for movie
                }
            });
        }else {
            viewContainer = (ViewContainer) view.getTag();
        }
        Movie movie = movies.get(position);

        viewContainer.txtMovieName.setText(movie.getTitle());
        Picasso.with(activity).load(movie.getImage()).fit().into(viewContainer.imgMoviePoster);
        viewContainer.linearLayoutMovieCard.setTag(position);

        Log.d(Variables.ADMIN, "Position: " + position);
        return view;
    }
}
