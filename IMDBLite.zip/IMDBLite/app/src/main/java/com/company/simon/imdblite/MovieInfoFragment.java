package com.company.simon.imdblite;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

public class MovieInfoFragment extends DialogFragment {

    private String username;
    public EditText inpUsername;
    public EditText inpPassword;
    private Button btnLoginFragment;
    private EditText txtUser, txtPassword;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        getDialog().setTitle(title);
        View view = inflater.inflate(R.layout.fragment_movie_info, container, false);
//        inpUsername = view.findViewById(R.id.inpUsername);
//        inpPassword = view.findViewById(R.id.inpPassword);


        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        return view;

    }



//    public void setTitle(String title) {
//        this.title = title;
//    }

    public void setInpUsername(EditText inpUsername) {
        this.inpUsername = inpUsername;
    }

}


