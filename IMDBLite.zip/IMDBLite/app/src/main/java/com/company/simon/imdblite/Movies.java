package com.company.simon.imdblite;

import java.util.ArrayList;

public class Movies {

    public static Movies movies;
    public ArrayList<Movie> movieArrayList;


    Movies(){
        movieArrayList = new ArrayList<>();
    }

    public static Movies getMovies(){
        if(movies == null){
            movies = new Movies();
            EventsTracker.moviesInClient = false;
        }else {
            EventsTracker.moviesInClient = true;
        }
        return movies;
    }

    public boolean addMovie(Movie movie){
        if(!movieArrayList.contains(movie)){
            movieArrayList.add(movie);
            return true;
        }else {
            return false;
        }
    }

    public int getMovieListSize(){
        return movieArrayList.size();
    }
}
