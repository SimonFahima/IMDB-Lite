package com.company.simon.imdblite;

public class EventsTracker {

    static boolean existingUser;
    static boolean moviesInClient;
}
