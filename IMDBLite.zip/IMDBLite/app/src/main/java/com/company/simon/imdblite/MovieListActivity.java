package com.company.simon.imdblite;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.style.TtsSpan;
import android.util.Log;
import android.util.Property;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

public class MovieListActivity extends AppCompatActivity {

    private Movies movies;
//    private List<Movie> movieList;
    private ArrayAdapter<Movie> movieArrayAdapter;
    private ListView movieListView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_list);
        movies = Movies.getMovies();
        movieListView = findViewById(R.id.movieList);
        new GetMoviesFromJSON().execute();
        saveMoviesFromJSONToRoomDatabase();


        if(!EventsTracker.existingUser){
            new GetMoviesFromJSON().execute();
        }else {
            //method for checking if info is in client and if not get from sqlite
            loadMoviesToAdapter();
        }
    }

    private void loadMoviesFromRoom() {
//        movieList = new ArrayList<>();
//        for (int i = 0; i < movies.getMovieListSize(); i++) {
//            Movie tempMovie = movies.movieArrayList.get(i);
//            Movie movie = new Movie(
//                    tempMovie.getTitle(),
//                    tempMovie.getImage(),
//                    tempMovie.getRating(),
//                    tempMovie.getReleaseYear(),
//                    tempMovie.getGenre());
//            movieList.add(movie);
//        }
    }

    private void loadMoviesToAdapter(){
        movieArrayAdapter = new MovieAdapter(this, movies.movieArrayList, this);

        movieListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String movie = String.valueOf(movies.movieArrayList.get(position));
                Toast.makeText(MovieListActivity.this, "You clicked on: " + movie, Toast.LENGTH_SHORT).show();


            }
        });
        movieListView.setAdapter(movieArrayAdapter);
    }


    @SuppressLint("StaticFieldLeak")
    private class GetMoviesFromJSON extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(MovieListActivity.this, "Json Data is downloading.",
                    Toast.LENGTH_LONG).show();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler httpHandler = new HttpHandler();
            String jsonString = httpHandler.makeServiceCall(Variables.MOVIE_LIST_API);

            if (jsonString != null) {
                try {
                    JSONArray jsonArray = new JSONArray(jsonString);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject movie = jsonArray.getJSONObject(i);
                        String title = movie.getString("title");
                        String image = movie.getString("image");
                        String rating = movie.getString("rating");
                        String releaseYear = movie.getString("releaseYear");
                        //fix problem
                        String genre = movie.getString("genre");

                        Movie movieObject = new Movie(title, image, rating, releaseYear, genre);
                        if(!movies.addMovie(movieObject)){
                            Log.d(Variables.ADMIN, "movie " + movieObject.getTitle() + " already exists");
                        }

                    }

                } catch (final JSONException e) {
                    e.getStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                            EventsTracker.moviesInClient = false;
                        }
                    });

                }

            } else {
                Log.d(Variables.ADMIN, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG).show();
                        EventsTracker.moviesInClient = false;
                    }
                });
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Log.d(Variables.ADMIN, "finished loading json result is - " + result);
            Toast.makeText(MovieListActivity.this, "Finished loading JSON", Toast.LENGTH_SHORT).show();
            EventsTracker.moviesInClient = true;
            loadMoviesToAdapter();
        }



        }

    public void saveMoviesFromJSONToRoomDatabase(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                AppDataBase dataBase = Room
                        .databaseBuilder(MovieListActivity.this, AppDataBase.class, "database")
                        .fallbackToDestructiveMigration()
                        .build();
                MovieDao movieDao = dataBase.movieDao();

                List<Movie> moviesList = movies.movieArrayList;

                for (int i = 0; i < moviesList.size(); i++){
                    movieDao.insertMovie(moviesList.get(i));
                }

                List<Movie> movies = movieDao.getMovies();
                for(Movie m : movies){
                    Log.d(Variables.ADMIN, m.toString());
                }
                dataBase.close();
            }
        }).start();

    }
}
