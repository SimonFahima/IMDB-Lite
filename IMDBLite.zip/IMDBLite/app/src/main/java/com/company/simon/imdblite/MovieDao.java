package com.company.simon.imdblite;

import java.util.List;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface MovieDao {

    @Query("SELECT * FROM movie")
    List<Movie> getMovies();

//    @Query("SELECT * FROM movie WHERE radius >= (:radius)")
//    List<Circle> getCirclesWithRadiusGreaterThan(int radius);

    @Query("SELECT * FROM movie WHERE uid = (:uid)")
    Movie getMovieById(int uid);

    @Insert
    void insertMovie(Movie... movies);

    @Delete
    void deleteMovie(Movie movie);
}
